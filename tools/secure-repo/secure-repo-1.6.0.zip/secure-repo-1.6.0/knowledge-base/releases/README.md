# Release Policy As Code

This is a knowledge base of the `release policy as code` files for open source GitHub releases and packages. These files are used by [Release Monitor](https://github.com/apps/stepsecurity-app) to verify that a new release followed the expected release process. 
