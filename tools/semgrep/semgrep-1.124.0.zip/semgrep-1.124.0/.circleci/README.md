This directory contains the Circle CI "pipeline" to automate certain tasks
(e.g., running semgrep on our PRs for dogfooding, running our parsing stats crons).
See https://circleci.com/docs/about-circleci for more information on Circle CI
as well as https://circleci.com/docs/concepts to understand its main concepts.
Note that the R2C Devops team supports only Github Actions, so
if you have problems with Circle CI, you are on your own.

You can also explore the Semgrep Circle CI pipelines here:
https://app.circleci.com/pipelines/github/returntocorp/semgrep
