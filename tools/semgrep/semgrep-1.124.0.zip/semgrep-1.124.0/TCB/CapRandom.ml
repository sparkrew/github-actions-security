let int _cap = Random.int
let get_state _cap = Random.get_state
let self_init _cap = Random.self_init
