(* just to speedup compilation *)

module UStdlib = Stdlib
module USys = Sys
module UUnix = Unix
module UPrintf = Printf
module UFormat = Format
module UMarshal = Marshal
module UParsing = Parsing
module UFilename = Filename
module URandom = Random
